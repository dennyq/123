package com.hs.web.mapper;


import com.hs.DbMap;

public interface MainMapper{

	DbMap login(DbMap map);

}
