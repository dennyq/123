package com.hs.web.mapper;


public interface CommonMapper extends CrudMapper{

}
