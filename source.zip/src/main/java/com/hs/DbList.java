package com.hs;
 
import java.util.ArrayList;

public class DbList extends ArrayList<DbMap>{

	/**
	 * 
	 */
	private static final long serialVersionUID = -265905699085578461L;

    public DbList() {

    }

    public DbList(int capacity) {
        super(capacity);
    }

}
